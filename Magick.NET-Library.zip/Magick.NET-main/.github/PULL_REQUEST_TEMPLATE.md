### Description
<!-- A description of the changes proposed in the pull-request -->

<!-- Thanks for contributing to Magick.NET! -->